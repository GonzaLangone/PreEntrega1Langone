import React from 'react'
import '../styles/navbar.scss'
import CardWidget from './CardWidget'

const Navbar = () => {
  return (
        <ul>
            
            <li><a className="active" href="#home">Home</a></li>
            <li><a href="#iphone">Iphone</a></li>
            <li><a href="#macbook">Macbook</a></li>
            <li><a href="#ipad">Ipad</a></li>
            <li><a href="#accesorios">Accesorios</a></li>
            <CardWidget></CardWidget>
        </ul>
  )
}

export default Navbar