import React, { useState } from 'react'
import carrito from '../assets/carrito.png' 




const CardWidget = () => {
  return (
    <>
    <img  className="carrito" src={carrito}/>
    <span>0</span>
    </>
    
  )
}

export default CardWidget