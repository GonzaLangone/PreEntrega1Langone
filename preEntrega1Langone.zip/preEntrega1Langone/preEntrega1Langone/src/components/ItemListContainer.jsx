import React from 'react'
import CardWidget from './CardWidget'


const ItemListContainer = ({greeting}) => {
  return (
    <>
    <h1 style={{textAlign:'center'}} >{greeting}</h1>

    </>
  )
}

export default ItemListContainer
